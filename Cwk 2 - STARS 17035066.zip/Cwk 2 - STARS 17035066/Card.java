

/**
 * The Card Class, has a load of methods which allow the manipulation of data relevent to the class
 *
 * @author Matthew Burrows
 * @version 0.1
 */
public class Card
{
    // instance variables - replace the example below with your own
    private int id_no; // creates variables with appropriate names for use within the class
    private int lux_rating;
    private int credit;
    private int loyalty;
    private String name = "name";

    /**
     * Constructor for objects of class Card, initialises values 
     */
    public Card(int tmp, String str,int r, int c )
    {
        // initialise instance variables
        id_no = tmp;
        name = str;
        lux_rating = r;
        credit = c;   
        loyalty = 0;
        
    }
    
    /**
     *  returns ID number of current card
     */
    public int id_no() { // returns the id_no of the current card
        return id_no;
        
    }
    
    /**
     *  returns the name of current card
     */
    public String Name(){ // returns the name of the current card
        return name;
        
    }
    
    /**
     *  returns the rating of current card
     */
    public int rating() { // returns the rating of the current card
        return lux_rating;
        
    }
    
    /**
     *  returns the loyalty balance of current card
     */
    public int loyalty() {
        return loyalty;
    }
    
    /**
     *  For testing, adds loyalty to card
     */
    public int addloyalty(int input) {
        loyalty += input;
        
        return loyalty;
    }
    
    /**
     *  returns balance of current card
     */
    public int balance() { // returns the balance of the current card
        return credit;
        
    }
        
    /**
     *  Increases the credit of the current card by the passed amount
     */
    public int addcredit(int input) // allows credits to be added to current card
    {
        // put your code here
                
        credit += input;
                
        return credit;
    }
    
    /**
     *  Decreases the credit of the current card by the passed amount
     */
    public int removecredit(int input) // allows credits to be removed from the current card
    {
        // put your code here
                
        credit -= input;
               
        return credit;
    }
    
    /**
     *  Converts the passed amount of credits into loyalty points at the confirmed rate
     */
    public int loyaltytocredit(int input) // allows loyalty points to be converted to credits
    {
        int tmp = input / 4; // creates a temporary int for use within this method
                
        if (input <= loyalty) { // checks if current card has enough loyalty points
            addcredit(tmp);     // calls the add credit function for the amount of credits they wanna convert at the correct rate
            loyalty -= input; // removes the converted loyalty to the credit total
        }
        
        return loyalty; // returns the loyalty points
    }
    
    /**
     *  Increases the loyalty points by 2
     */
    public int addloyalty(){ // adds 2 loyalty points, for use when a journey is made
        loyalty += 2; // adds 2 loyalty points to total
        
        return loyalty; // returns the loyalty points
    }
    
    /**
     *  Checks if card has enough credits to start a journey
     */
    public boolean tripchecker() // checks if current card can make a journey
    {
        if (3 <= credit) { // if they have enough credits for a shuttle journey (3) return true
            return true; 
        }
        else { // else return false
            return false;
        }
        
    }
    
    /**
     *  checks if the current cards id is same as parameter
     */
    public boolean idchecker(int input) // checks if the current cards id is same as parameter
    {
        
        if (input == id_no){ // if id_no is same as the int input return true
            
            return true;
        }
        
        return false; // else return false
    }
    
    /**
     *  Returns all current card data as string
     */
    public String toString() // takes all current card data and puts it into a string
    {
        String user_data; // creates a string for use in this method
        user_data = "id_no: " + id_no + ", Name: " + name + ", luxury Rating: " + lux_rating + ", Credits " + credit + ", Loyalty Points: " + loyalty;   
        
        return user_data; // returns the string with all the data
    }
}
