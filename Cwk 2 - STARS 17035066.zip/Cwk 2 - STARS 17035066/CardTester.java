 
/**
 * CardTester checks all methods within the class Card, to see if they function the way they should.
 *
 * @author Matthew Burrows
 * @version 0.1
 */
public class CardTester
{
    // instance variables - replace the example below with your own
    Card card1 = new Card(1000 , "Lynn", 5 , 10 ); // creates a few cards for use within this tester
    Card card2 = new Card(1001 , "May", 3 , 30);
    Card card3 = new Card(1002 , "Nils" , 10 , 25);
   
    public void main(){ // main method for this tester which tests all methods in card

       
        System.out.println("#######"); // prints a line of #s to make it clear which test it is 
        System.out.print("Card 1 Tests");
        System.out.println(); // prints a blank line
        
        System.out.println(card1.toString()); // runs the tostring function for card1
        System.out.println(card1.id_no()); // prints card2 id number
        System.out.println(card1.Name()); // prints the name of card1
        System.out.println(card1.rating()); // prints the rating of card1
        System.out.println(card1.addcredit(45)); //adds credits to card1
        System.out.println(card1.removecredit(5)); //removes credits from card1
        System.out.println(card1.loyaltytocredit(8)); //trys to convert loyalty to credit, wont work as loyalty is 0
        System.out.println(card1.tripchecker()); // checks if they can make a journey
        System.out.println(card1.idchecker(1)); // checks the id number

        System.out.println("#######"); // prints a line of #s to make it clear which test set it is 
        System.out.print("Card 2 Tests");
        System.out.println(); // prints a blank line
        
        System.out.println(card2.toString()); // runs the tostring function for card2
        System.out.println(card2.id_no()); // prints card2 id number
        System.out.println(card2.Name()); // prints the name of card2
        System.out.println(card2.rating()); // prints the rating of card2
        System.out.println(card2.addcredit(67)); //adds credits to card2
        System.out.println(card2.removecredit(13)); //removes credits from card2
        System.out.println(card2.loyaltytocredit(22)); //trys to convert loyalty to credit, wont work as loyalty is 0
        System.out.println(card2.tripchecker()); // checks if they can make a journey
        System.out.println(card2.idchecker(1001)); // checks the id number
        
        System.out.println("#######"); // prints a line of #s to make it clear which test it is 
        System.out.print("Card 3 Tests");
        System.out.println(); // prints a blank line
        
        System.out.println(card3.toString()); // runs the tostring function for card3
        System.out.println(card3.id_no()); // prints card3 id number
        System.out.println(card3.Name()); // prints the name of card3
        System.out.println(card3.rating());// prints the name of card3
        System.out.println(card3.addcredit(37));//adds credits to card3
        System.out.println(card3.removecredit(3));//removes credits from card3
        System.out.println(card3.loyaltytocredit(80));//trys to convert loyalty to credit, wont work as loyalty is 0
        System.out.println(card3.tripchecker()); // checks if they can make a journey
        System.out.println(card3.idchecker(35));   // checks the id number     
    }
}
