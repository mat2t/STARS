
import java.util.ArrayList;
/**
 * World class, contains methods used for manipulating world data and controlling entrance to and exit from the planet
 *
 * @author Matthew Burrows
 * @version 0.1
 */
public class World
{
    // instance variables - replace the example below with your own
    private int planet_id; // creates local variables with relevant names
    private String name;
    private int rate;
    private int capacity;
    private int guesti;
    private int maxlen;
    
    /* Card[] cardlist = new Card[maxlen];
    Card[] allcards = new Card[12]; */
    
    private ArrayList<Card> cardlist; // creates an arraylist for storing all cards on current planet
    
    /**
     * Constructor for objects of class World
     */
    public World(int id, String nam, int ra, int cap) // takes parameters to allow for different worlds to be created
    {
        // initialise instance variables
        planet_id = id;
        name = nam;
        rate = ra;
        capacity = cap;
        guesti = 0;
        maxlen = 0;
        
        cardlist = new ArrayList<Card>(); // initialises the arraylist
        
        
    }
    
    /**
     *  Returns the current planets ID number
     */
    public int id_no() //returns the planet id number
    {
                
        return planet_id;
    }
    
    /**
     *  Returns the current planets rating
     */
    public int rating(){ // returns the planet rating
        
        return rate;
    }
    
    /**
     *  Returns the current planets name
     */
    public String name() // returns the planets name
    {
        return name;
    }
    
    /**
     *  Returns the current planets capacity 
     */
    public int capacity(){ // returns the capacity for the current planet
        return capacity;
        
    }
    
    /**
     * 
     *  Booleans function that checks if the current world has space and returns true if full, false otherwise
     *  
     *  
     */
    public boolean capacitychecker()  // checks the capacity of current world
    {
        
        int tmp; // creates a local variable
        tmp = capacity - guesti; // takes away current guest number from the capacity
                
        if (guesti == capacity) {     // if the capacity 
            return true;
        }
        
        return false;
    }
    
    /**
     *  Converts current world data into a string and returns it
     */
    public String toString() // takes all card data and puts it in a string
    {
        String planet_data; // creates a local string
        planet_data = "planet_id: " + planet_id + ", Name: " + name + ", luxury Rating: " + rate + ", Capacity " + capacity;     
        
        return planet_data;
    }
    
    //public void Lengthinc(){
    //    int tmp = 0;
        
    //    tmp = maxlen;
    //    maxlen++;
    //    Card[] tmplist = new Card[maxlen];
        
    //    System.arraycopy(cardlist, 0, tmplist, 0, tmp);
    //    cardlist = tmplist;
        
    //}
    
    //public void Lengthdec(){
    //    maxlen--;
        
    //}
    
    /**
     *  adds a card to the cardlist for current planet
     */
    public void enter(Card a) 
    {
        cardlist.add(a); // adds the card parameter to the cardlist
        
        guesti =  cardlist.size(); // sets the int guesti to the size of the cardlist
        
        /* Lengthinc();
        
        if (guesti < capacity) {
            System.out.print("The guest " + newcard.name + " has entered the planet \nThere are now "+ maxlen + " guest(s) on the planet\n");
            cardlist[guesti++] = newcard;
        }
        
        if (guesti == capacity) {
            System.out.print("Sorry, there are no spaces left on the planet " + name + "\n");
            
        }
        
        */
    }
    
    /**
     *  removes the chosen card from the cardlist for current planet
     */
    public void leave(int b) //removes a card from the current cardlist
    {
        Card tmp = null; // creates a card called tmp and initialises it to null
        
        for(int i=0; i < cardlist.size(); i++){ // for int i, where i is less than the size of cardlist
            tmp = cardlist.get(i); // card tmp to the current card
            if (tmp.id_no() == b) { // if the current cards id number = the passed id
               tmp = cardlist.get(i);       // store current card in tmp
               break; // break the loop
            }
            
        }
        
        if (tmp != null){ // tmp is not empty
            cardlist.remove(tmp); // remove it from the cardlist
        }
              
        guesti = cardlist.size(); // change the size of guesti to the new size of the cardlist
        /* int index = 0;
        
        Card[] tmplist = new Card[maxlen-1];
        for(int i = 0; i < cardlist.length; i++){
            if (cardlist[i].id_no == newcard.id_no && cardlist[i].name == newcard.name) {
               index = i;
            }        
        }
        
        System.out.print("The guest " + cardlist[index].name + " has left the planet");
        
        for(int i = 0; i < cardlist.length; i++){
            if (i < index){
               tmplist[i] = cardlist[i];                
            }            
            else if (i>index){
                tmplist[i-1] = cardlist[i];
            }
        }     
        cardlist = tmplist;
        guesti--;
        Lengthdec();
        System.out.print("\nThere are now " + maxlen + " guest(s) on the planet\n");
        
        */
    }
    
    /**
     *  Stores all cards on the current world into a string and returns the string
     */
    public String printcardlist(){ // stores all cards on world in an arraylist
        String allcards = " "; // initialise the string as an empty char
        
        Card tmp = null; // create a card called tmp and initialise it to null
        if (cardlist.size() != 0){ // if the cardlist length doesnt equal 0
          for(int i=0; i < cardlist.size(); i++){ // for each card stored in the cardlist
              
              tmp = cardlist.get(i); // get the current card and store it in tmp
              allcards += tmp + "\n"; // place the current card into the string followed by a linebreak
          }
        }else{
            allcards +="\n No cards!\n\n"; //if no cards are on the current planet add "no cards" to the string
        }
        /* for(int i = 0; i < cardlist.length; i++){
            System.out.print("\n" + cardlist[i] + "\n");
        }*/
        return allcards; // returns the string allcards
    }
   
    /**
     *  Boolean function that checks if the current card id number is present in the cardlist for the planet
     */
    public boolean cardcheck(int check){ // searches cardlist for 
        
        for(int i=0; i < cardlist.size(); i++){ // for loop that looks at all cards in the cardlist one by one
            Card tmp = cardlist.get(i); // creates a card called tmp and sets it to the current card
            if (tmp.id_no() == check) { // if current cards id number is same as parameter
                return true;
                
            }
            
        }
        
        
        /*for(int i = 0; i < cardlist.length; i++){
            if (cardlist[i].id_no == check.id_no && cardlist[i].name == check.name) {
               System.out.print("\nThis card is present on this planet\n");
               return true;
            }        
        }
        
        System.out.print("\nThis card is not present on this planet\n");
        return false;
        }*/
        return false;
    }
}
