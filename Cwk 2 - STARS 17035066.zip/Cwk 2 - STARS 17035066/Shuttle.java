
/**
 * The shuttle class has several methods for checking if a journey is doable and if it actually can be made
 *
 * @author Matthew Burrows
 * @version 0.1
 */
public class Shuttle
{
    // instance variables - replace the example below with your own
    private String j_id;
    private World start;
    private World end;

    /**
     * Constructor for objects of class Shuttle
     */
    public Shuttle(String jid, World s , World e) {
        // initialise instance variables
        j_id = jid;
        start = s;
        end = e;
    }
    
    /**
     * Returns the shuttle id for the current shuttle
     */
    public String j_id(){
        return j_id;
        
    }
    
    /**
     * Returns the world data for the start world
     */
    public World startworld(){
        return start;
        
    }
    
    /**
     * Returns the data for the destination world
     */
    public World endworld(){
        return end;
        
    }
    
    /**
     * Checks if a journey can be made based off of the parameter card and some set conditions
     *
     */
    public boolean journeycheck(Card c)
    {
        // if the start or end world is null 
        // if the cards rating is higher or equal to world and they have 3 or more credits and the world isnt full and the current card is listed on the start planet sets to true
        if (end != null || start != null){
            if (c.rating() >= end.rating() && c.balance() >= 3 && end.capacitychecker() != true && start.cardcheck(c.id_no()) == true) {
                return true;
            
            }  
        
        }
        return false;
    }
    
    /**
     * String function that prints a string saying what the issue is
     */
    public String reasonforfailedtravel(Card c){
        String str = " "; // creates a blank string
        if ( c.rating() < end.rating()){ // if card has lower rating than destination world
            str = "Card lacks sufficient rating"; // stores message is string str
        }
        if ( c.balance() < 3 ) { // if card has less than 3 credits
            str = "Card has insufficient credits"; // stores message is string str
        }
        if ( end.capacitychecker() == true ){ // if world is full
            str = "Destination world is full"; // stores message is string str
        }
        if ( start.cardcheck(c.id_no()) == false ){ // if card is not on start world
            str = "Chosen card is not on start world"; // stores message is string str
        }
        return str;
    }
    
    /**
     * Boolean journey, processes the actual journey
     */
    public boolean journey(Card guest) {
        boolean checked = journeycheck(guest); // creates a boolean called check and sets it to the output of journeycheck
        if (checked == true){ // if checked is true
            guest.addloyalty(); // adds 2 loyalty points
            guest.removecredit(3); // removes 3 credits from balance
            start.leave(guest.id_no()); // removes the card from the start planets arraylist
            end.enter(guest); // adds the card to the destination arraylist
            return true;
        }
        
        return false;
    }
    
    /**
     * String function that prints a string containing the shuttle infomation 
     */
    public String toString(){
        String j_data;
        j_data = "Shuttle ID: " + j_id + ", start world " + start + ", destination: " + end;   
        
        return j_data;
    }
}
