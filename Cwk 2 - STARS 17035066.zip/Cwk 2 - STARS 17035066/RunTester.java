 
/**
 * Write a description of class RunTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RunTester
{ 
    public static void coreTasksTest()
    {
        MyTester xx = new MyTester();
        xx.coretasks();
        
        
        
    }
    
    public static void extensionTaskTest()
    {
        MyTester xx = new MyTester();
        xx.extensiontasks();
        
        
    }
}
