
/**
 * Runner runs the ui.
 *
 * @author Matthew Burrows
 * @version 0.1
 */
public class Runner
{
    public static void main()
    {
        ResortUI xxx = new ResortUI();
        xxx.runUI();
    }
}
