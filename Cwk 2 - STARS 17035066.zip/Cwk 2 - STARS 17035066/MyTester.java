 
/**
 * Tester tests that the system is functioning as intended
 * 
 * @author Matthew Burrows 
 * @version 0.1
 */
public class MyTester 
{   
    public void coretasks()
    { ResortManager wayward = new ResortManager();
      
      
       System.out.println(" --------- Cards --------- ");
       System.out.println(wayward.getAllCardsOnEachWorld()); // prints all cards on each world 
       
       System.out.println(" --------- Cards on world Home --------- ");
       System.out.println(wayward.getAllCardsOnWorld("Home")); // prints all cards on the world home 
       System.out.println(" --------- Cards on world Sprite --------- ");
       System.out.println(wayward.getAllCardsOnWorld("Sprite")); // prints all cards on the world sprite 
       
       System.out.println(" --------- finding cards --------- ");
       System.out.println("Searching for id 1000"); // searches all worlds for id 1000
       System.out.println(wayward.findCard(1000));
       System.out.println("Searching for id 9999"); // searches all worlds for id 9999
       System.out.println(wayward.findCard(9999));
       
       System.out.println(" --------- Get world number --------- ");
       System.out.println("Searching for Home"); // searches for id number of world home
       System.out.println(wayward.getWorldNumber("Home"));
       System.out.println("Searching for Solo"); // searches for id number of world solo
       System.out.println(wayward.getWorldNumber("Solo"));
       
       
       System.out.println(" --------- Check if card can travel --------- ");
       System.out.println("Checking if id 1000 can travel to Sprite");
       System.out.println(wayward.canTravel(1000, "ABC1")); // checks if id 1000 can go to sprite from home
       System.out.println("Checking if id 1000 can travel to Home");
       System.out.println(wayward.canTravel(1000, "BCD2")); // checks if id 1000 can go to home from sprite
       System.out.println("Checking if id 1001 can travel to Sprite");
       System.out.println(wayward.canTravel(1001, "ABC1")); // checks if id 1000 can go to sprite from home
       System.out.println("Checking if id 1001 can travel to Home");
       System.out.println(wayward.canTravel(1001, "BCD2")); // checks if id 1000 can go to home from sprite
        
       System.out.println(" --------- Check if card does travel --------- ");
       System.out.println("Checking if id 1000 travels to Sprite"); // moves id 1000  to sprite from home
       System.out.println(wayward.travel(1000, "ABC1"));
       System.out.println("Checking if id 1000 travels to Home"); // moves id 1000  to home from sprite
       System.out.println(wayward.travel(1000, "BCD2"));
       System.out.println("Checking if id 1001 travels to Sprite"); // moves id 1001  to sprite from home
       System.out.println(wayward.travel(1001, "ABC1"));
       System.out.println("Checking if id 1001 travels to Tropicana");// moves id 1001  to tropicana from sprite
       System.out.println(wayward.travel(1001, "CDF3"));
       System.out.println("Checking if id 1001 travels to Fantasia"); // moves id 1001  to fantasia from tropicana
       System.out.println(wayward.travel(1001, "JKL8"));
       System.out.println("Checking if id 1001 travels to Sprite"); // moves id 1001  to sprite from fantasia
       System.out.println(wayward.travel(1001, "DEF4"));
       System.out.println("Checking if id 1002 travels to Sprite"); // moves id 1002  to sprite from home
       System.out.println(wayward.travel(1002, "ABC1"));
       System.out.println("Checking if id 1002 travels to Solo"); // moves id 1002  to solo from sprite
       System.out.println(wayward.travel(1002, "GHJ6 "));
       
      
    }
    
    public void extensiontasks(){
       ResortManager wayward = new ResortManager();
       
       
       System.out.println(" --------- Update card balance --------- ");
       System.out.println("Checking if id 1000 gains 30 credits"); // adds 30 credits to id 1000
       wayward.topUpCredits(1000, 30);
       System.out.println("Checking if id 1001 gains 400 credits"); // adds 400 credits to id 1000
       wayward.topUpCredits(1000, 30);
       
       System.out.println(" --------- Go Home --------- ");
       System.out.println("Telling card id 1000 to go home"); // moves id 1000 from current world to home
       wayward.moveHome(1000);
       System.out.println("Telling card id 1003 to go home"); // moves id 1003 from current world to home
       wayward.moveHome(1003);
       
       System.out.println(" --------- Convert loyalty --------- ");
       System.out.println("converting card 1000 loyalty points to credits"); // converts id 1000 loyalty points to credits
       wayward.convertPoints(1000);
       System.out.println("converting card 1002 loyalty points to credits"); // converts id 1002 loyalty points to credits
       wayward.convertPoints(1002);
       
       System.out.println(" --------- Evacuate all --------- ");
       System.out.println("Taking all cards home"); // takes all cards home
       wayward.evacuateAll();
       System.out.println(wayward.getAllCardsOnEachWorld()); // prints all cards on all worlds to show if worked or not
        
       
        
        
        
        
    }
}
