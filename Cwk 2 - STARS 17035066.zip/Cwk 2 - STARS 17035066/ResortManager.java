
            
import java.util.*;
            
/**This class implements Cwk 2
 *
 * @author A.A.Marczyk + Matthew Burrows
 * @version 09/02/20
 **/
 public class ResortManager 
    {
        //ResortManager Fields 
        private String location;
        private ArrayList<Card> allcards;
        private ArrayList<World> allworlds;
        private ArrayList<Shuttle> allshuttles;
               
        /**
         * Constructor for ResortManager
         * 
         **/
        public ResortManager() {
           location = "Wayward";
                   
           allcards = new ArrayList<Card>();
           allworlds = new ArrayList<World>();
           allshuttles = new ArrayList<Shuttle>();
                
           loadCards();
           loadWorlds();
           setUpShuttles();
                 
           World Home = allworlds.get(0);
                   
           for(Card i : allcards){
               Home.enter(i);             
                        
           }
    }
                   
        /**
         * Returns all of the data about all worlds including the cards
         * currently on each world, r "No cards"
         * @return all of the details of all worlds including  
         * and all cards currently on each world, or "No cards" 
         */
        public String toString()
        {
            String st = " ";
            for(World i : allworlds){
               st += i.toString() + "\n";       
               st += i.printcardlist();
            }
            
            return st;
    }
            
        /**Returns a String representation of all the cards on all worlds, listed 
         * by world 
         * @return a String representation of all cards on all worlds
         **/
        public String getAllCardsOnEachWorld()
        {
            String str = " ";
            for(World i : allworlds){
               str += i.name() + "\n";
               str += i.printcardlist();
            }
               System.out.print(str);
               return str;
    }
                
                
        /**Returns the name of the world which contains the specified card or null
         * @param cr - the specified card
         * @return the name of the World which contains the card, or null
         **/
        public String findCard(int cr)
        {
            String name = null;
            boolean found = false;
                    
            for(World i : allworlds){
               if (i.cardcheck(cr) == false){
                   return name;
                }
               else {
                   found = true;
                }
               if (found == true) {
                   name = i.name();
                   return name;
               }
            }
            
            return name;
    }
                
                
        /** Given the name of a world, returns the world id number
         * or -1 if world does not exist
         * @param name of world
         * @return id number of world
         */
        public int getWorldNumber(String ww)
        {
            int id = -1;
                    
            for(World i : allworlds){
                if (i.name() == ww) {
                    id = i.id_no();               
                }           
            }
            return id;
    }
            
                        
        /**Returns a String representation of all the cards on specified world
             * @return a String representation of all cards on specified world
             **/
        public String getAllCardsOnWorld(String world)
        {
            String stri = " ";
            for(World i : allworlds){           
             if (i.name().equals(world)){
                  stri += i.printcardlist() + "\n";
                      
             }
           }
                
           return stri;
    }
            
       /**Returns true if a Card is allowed to move using the shuttle, false otherwise
             * A move can be made if:  
             * the rating of the card  >= the rating of the destination world
             * AND the destination world is not full
             * AND the card has sufficient credits
             * AND the card is currently in the source world
             * AND the card id is for a card on the system
             * AND the shuttle code is the code for a shuttle on the system
             * @param crId is the id of the card requesting the move
             * @param shtlCode is the code of the shuttle journey by which the card wants to pCardel
             * @return true if the card is allowed on the shuttle journey, false otherwise 
             **/
       public boolean canTravel(int crId, String shtlCode)
       {
           Card cardfound = new Card(999,null,999,999);
           Shuttle shuttlefound = new Shuttle(null,null,null);
                           
           for(Card i : allcards){
              if (i.id_no() == crId){
                  cardfound = i;
                  break;
               }
           }
           for(Shuttle y : allshuttles){
              if (y.j_id().equals(shtlCode)){
                  shuttlefound = y;
                  break;
              }
            
           }
       
            if (shuttlefound == null || cardfound == null) {
               return false;
           }
           
           if (shuttlefound.journeycheck(cardfound) == true) {
               return true;
           }
           return false;
    }
    

    /**Returns the result of a card requesting to move by Shuttle.
     * A move will be successful if:  
     * the luxury rating of the card  >= the luxury rating of the destination world
     * AND the destination world is not full
     * AND the card has sufficient credits
     * AND the card is currently in the source world
     * AND the card id is for a card on the system
     * AND the shuttle code is the code for a shuttle on the system
     * If the shuttle journey can be made, the card information is removed from the source
     * world, added to the destination world and a suitable message returned.
     * If shuttle journey cannot be made, the state of the system remains unchanged
     * and a message specifying the reason is returned.
     * @param pCardId is the id of the card requesting the move
     * @param shtlCode is the code of the shuttle journey by which the card wants to pCardel
     * @return a String giving the result of the request 
     **/
    public String travel(int pCardId, String shtlCode )
    {
        String stri = " ";
        Card cardfound = null;
        Shuttle shuttlefound = null;

        
        for(Card i : allcards){
           if (i.id_no() == pCardId){
               cardfound = i;
               break;
            }
        }
        
        for(Shuttle y : allshuttles){
           if (y.j_id().equals(shtlCode)){
               shuttlefound = y;
               break;
            }
            
        }
        
        if (shuttlefound == null || cardfound == null) {
             stri = "The journey could not be made, system has not been changed, Reason: Unknown error occured";
             return stri;
        }
        if (canTravel(pCardId, shtlCode) == true){
            shuttlefound.journey(cardfound);
            stri = "The journey was a success";
        }else{
            stri = "The journey could not be made, system has not been changed, Reason: " + shuttlefound.reasonforfailedtravel(cardfound);
        }
        
        return stri;
    }
    
     
    // These methods are for Task 6 only and not required for the Demonstration 
    // If you choose to implement them, uncomment the following code    
    /** Allows a card to top up their credits.This method is not concerned with 
      *  the cost of a credit as currency and prices may vary between resorts.
      *  @param id the id of the card toping up their credits
      *  @param creds the number of credits purchased to be added to cards information
      */
     public void topUpCredits(int id, int creds)
     {
            Card updateme = null;
                    
            for(Card i : allcards){
              if (i.id_no() == id){
                  updateme = i;
                  break;
               }
           }
           
           updateme.addcredit(creds);
           System.out.println(updateme.balance());
     }
    
     /** Moves a card directly back to the home world without affecting credits
      *  and not using existing shuttles
      */
     public void moveHome(int id)
     {
         World tmpworld = null;
         World home = null;
         
         Card updateme = null;
         
         home = allworlds.get(0);
         
         for(Card i : allcards){
            if (i.id_no() == id){
                updateme = i;
                System.out.println("Moving card: "+ i.id_no());
                break;
             }
         }
         for(World i : allworlds){
                if (i.cardcheck(id) == true) {
                    
                    tmpworld = i;   
                    break;
                }      
            }
            
         if (tmpworld != null && home != null && updateme != null) { 
           System.out.println("Card home");
           tmpworld.leave(id);
           home.enter(updateme);
         }
         
     }
  
    /** Converts a card's loyalty points into credits
      * @param tr the id of the card whose points are to be converted
      */
     public void convertPoints(int id)
     {
         
         
         for(Card i : allcards){
            if (i.id_no() == id){
                System.out.println("Old balance" + i.balance());
                int tmp = i.loyalty();
                System.out.println("current loyalty: " + tmp);
                i.loyaltytocredit(i.loyalty());
                System.out.println("New balance: " + i.balance());
                tmp = i.loyalty();
                System.out.println("new loyalty: " + tmp);
                break;
             }
            }
     }
    
     /** In an emergency, evacuates all cards directly back to the home world without 
      * affecting credits or other information and not using existing shuttles
      */
     public void evacuateAll()
     {
         for(Card i : allcards){
             moveHome(i.id_no());
            }
     }
    
   
    
    
    //***************private methods**************
    // create all cards in Appendix A and addthem to their collection
    /**
      * Creates and stores all cards into the arraylist allcards
      * 
     **/
    private void loadCards()
    {
      Card card1 = new Card(1000 , "Lynn", 5 , 10 );
      allcards.add(card1);
      Card card2 = new Card(1001 , "May", 3 , 30);
      allcards.add(card2);
      Card card3 = new Card(1002 , "Nils" , 10 , 25);
      allcards.add(card3);
      Card card4 = new Card(1003 , "Olek" , 2 , 12);
      allcards.add(card4);
      Card card5 = new Card(1004 , "Pan" , 3 , 3);
      allcards.add(card5);
      Card card6 = new Card(1005 , "Quinn" , 1 , 30);
      allcards.add(card6);
      Card card7 = new Card(1006 , "Raj" , 10 , 6);
      allcards.add(card7);
      Card card8 = new Card(1007 , "Sol" , 7 , 20);
      allcards.add(card8);
      Card card9 = new Card(1008 , "Tel" , 6 , 30);
      allcards.add(card9);      
      
    }
    
    // create all worlds in Appendix A and addthem to their collection
    /**
      * Creates and stores all worlds into the arraylist allworlds
      * 
     **/
    private void loadWorlds()
    {
      World world1 = new World(0 , "Home" , 0 , 1000);
      allworlds.add(world1);
      World world2 = new World(1 , "Sprite" , 1 , 100);
      allworlds.add(world2);
      World world3 = new World(2 , "Tropicana" , 3 , 10);
      allworlds.add(world3);
      World world4 = new World(3 , "Fantasia" , 5 , 2);
      allworlds.add(world4);
      World world5 = new World(4 , "Solo" , 1 , 1);
      allworlds.add(world5);
    }
    
    // create all shuttles in Appendix A and addthem to their collection
    /**
      * Creates and stores all shuttles into the arraylist allshuttles
      * 
     **/
    private void setUpShuttles()
    {
      Shuttle shuttle1 = new Shuttle("ABC1" , allworlds.get(0) , allworlds.get(1) );
      allshuttles.add(shuttle1);
      Shuttle shuttle2 = new Shuttle("BCD2 " , allworlds.get(1) ,allworlds.get(0));
      allshuttles.add(shuttle2);
      Shuttle shuttle3 = new Shuttle("CDF3" , allworlds.get(1) , allworlds.get(2));
      allshuttles.add(shuttle3);
      Shuttle shuttle4 = new Shuttle("DEF4" , allworlds.get(2) , allworlds.get(1));
      allshuttles.add(shuttle4);
      Shuttle shuttle5 = new Shuttle("EFG5 " , allworlds.get(3) , allworlds.get(1));
      allshuttles.add(shuttle5);
      Shuttle shuttle6 = new Shuttle("GHJ6 " , allworlds.get(1) , allworlds.get(4));
      allshuttles.add(shuttle6);
      Shuttle shuttle7 = new Shuttle("HJK7 " , allworlds.get(4) , allworlds.get(1));
      allshuttles.add(shuttle7);
      Shuttle shuttle8 = new Shuttle("JKL8 " , allworlds.get(2) , allworlds.get(3));
      allshuttles.add(shuttle8);
    }
    
    
//  // Uncomment if you want to use.
//     /** Returns the card with the card id specified by the parameter
//      * @return the card with the specified name
//      **/
//     public Card getCard(int id)
//     {
//         return null;
//     }
//     
//     /** Returns the world with the name specified by the parameter
//      * @return the world with the specified name
//      **/
//     private World getWorld(String worldName)
//     {
//         return null;
//     }
//     
//     /** Returns the world with the name specified by the parameter
//      * @return the world with the specified name
//      **/
//     private Shuttle getShuttle(String shut)
//     {
//         return null;
//     }
}